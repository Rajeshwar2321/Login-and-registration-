# Animated Login and Sign up Page

## Video (https://youtu.be/4XRZWOAf-hQ)

!["Make animated Login and Sign Up Page"](https://raw.githubusercontent.com/ziddahedem/animated_login_signup/master/images/screenshot_2.png "Make animated Login and Sign Up Page")

!["Make animated Login and Sign Up Page"](https://raw.githubusercontent.com/ziddahedem/animated_login_signup/master/images/screenshot_1.png "Make animated Login and Sign Up Page")
